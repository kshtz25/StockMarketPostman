package com.stock.StockME.Controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.stock.StockME.Model.Company;
import com.stock.StockME.Model.StockPrice;
import com.stock.StockME.Service.CompanyService;
import com.stock.StockME.Service.StockPriceService;



@RestController
public class CompanyController {
	
	@Autowired
	CompanyService companyService;
	@Autowired
	StockPriceService stockPriceService;
	
	@PostMapping("/company/add")
	public Company addCompany(@RequestBody Company company) throws SQLException {
		
		return companyService.insertCompany(company);
	}
	
	
	@GetMapping("/companies")
	public List<Company> getCompanies() throws SQLException{
		
		return companyService.getCompanyList();
		
	}
	@GetMapping("/companieslist/{sectorName}")
	public List<Company> getCompaniesList(@PathVariable String sectorName) throws Exception
	{
		
		return companyService.getCompanyListSector(sectorName);
		
	}
	@GetMapping("/matchingcompanies/{pattern}")
	public List<String> companyPatternMatching(@PathVariable("pattern") String pattern) throws Exception
	{
		
			return companyService.getPattern(pattern);
		
	}
	@GetMapping("/companystockprice/{companyname}")
	public List<StockPrice> getCompanyStockPice(@PathVariable("companyname") String companyName  ) throws Exception
	{
		return stockPriceService.getStockPriceByCompany(companyName);
	}
	@GetMapping(path = "/company/{id}")
	public Optional<Company> getCompanyById(@PathVariable int id) {
		System.out.println("Get company with id " + id);
		return companyService.getCompanyById(id);
	}

	@DeleteMapping(value="/companies/{id}")
	public ResponseEntity<String> deleteCompany(@PathVariable("id") int id){
		
		return companyService.deleteCompany(id);
		
	}
	@PutMapping("/customers/{id}")
	public ResponseEntity<String> updateCustomer(@PathVariable("id") Company id, @RequestBody Company company) {
		return companyService.updateCompany(id);

	}

}
