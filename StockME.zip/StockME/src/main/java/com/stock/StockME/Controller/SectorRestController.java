package com.stock.StockME.Controller;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.stock.StockME.Model.Sector;
import com.stock.StockME.Model.StockPrice;
import com.stock.StockME.Service.SectorService;




@RestController
public class SectorRestController {
	@Autowired
	SectorService sectorService;		
	@GetMapping("/sectorprice/{sectorname}/{from}/{to}")
	List<StockPrice> getSectorPrice(@PathVariable("sectorname") String sector ,@PathVariable("from")String from,@PathVariable("to")String to) throws ClassNotFoundException, SQLException, ParseException
	{
		DateFormat datefm = new SimpleDateFormat("dd-MM-yyyy");
		return sectorService.getSectorPrice(sector,datefm.parse(from),datefm.parse(to));
		
	}
	@PostMapping("/sector/add")
	public Sector addSector(@RequestBody Sector sector) throws SQLException, ClassNotFoundException {
		
		return sectorService.insert(sector);
	}
	
	
	@GetMapping("/sectors/all")
	public List<Sector> getSectors() throws SQLException, ClassNotFoundException{
		
		return sectorService.getAllSector();
		
	}

	@DeleteMapping(value="/sectors/{id}")
	public ResponseEntity<String> deleteSector(@PathVariable("id") int id){
		
		return sectorService.deleteSector(id);
		
	}
	@PutMapping("/sectors/{id}")
	public ResponseEntity<String> updateCustomer(@PathVariable("id") Sector id, @RequestBody Sector sector) {
		return sectorService.updateSector(id);


	}
}
