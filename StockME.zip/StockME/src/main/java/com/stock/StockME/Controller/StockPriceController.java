package com.stock.StockME.Controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.stock.StockME.Model.StockPrice;
import com.stock.StockME.Service.StockPriceService;



@RestController
public class StockPriceController {
 
	@Autowired
	public StockPriceService stockPriceService;
	
	
	@PostMapping("/stock-price/add")
	public StockPrice addStockPrice(@RequestBody StockPrice stockPrice) throws SQLException {
		
		return stockPriceService.insertStockPrice(stockPrice);
	}
	@PostMapping("/stock-price/update")
	public ResponseEntity<String> updateStockprice(@RequestBody StockPrice stockPrice) throws SQLException {
		
		return stockPriceService.updateStockPrice(stockPrice);
	}
	
	
	@GetMapping("/stock-prices/all")
	public List<StockPrice> getStockPrice() throws SQLException{
		
		return stockPriceService.getStockPriceList();
		
	}
	@GetMapping("/stock-prices/{companyname}")
	public List<StockPrice> getCompanyStockPice(@PathVariable("companyname") String companyName  ) throws Exception
	{
		return stockPriceService.getStockPriceByCompany(companyName);
	}
	@DeleteMapping(value="/stock-price/{id}")
	public ResponseEntity<String> deleteStockprice(@PathVariable("id") int id){
		
		return stockPriceService.deleteStockPrice(id);
		
	}
}
