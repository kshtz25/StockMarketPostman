package com.stock.StockME.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stock.StockME.Model.IPOPlaned;


public interface IPOPlanedDao extends JpaRepository<IPOPlaned, Integer>{
	IPOPlaned findByCompanyName(String companyName);
}
