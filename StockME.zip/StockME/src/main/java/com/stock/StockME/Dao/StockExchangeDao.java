package com.stock.StockME.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stock.StockME.Model.StockExchange;




public interface StockExchangeDao extends JpaRepository<StockExchange, Integer>{

}
