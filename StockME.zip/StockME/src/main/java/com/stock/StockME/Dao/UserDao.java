package com.stock.StockME.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stock.StockME.Model.User;



public interface UserDao extends JpaRepository<User, Integer>{
	 
	 
}
