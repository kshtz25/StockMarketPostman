package com.stock.StockME.Service;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.stock.StockME.Model.Company;



public interface CompanyService {
	public Company insertCompany(Company company) throws SQLException;

	public ResponseEntity<String> updateCompany(Company company);

	public List<Company> getCompanyList() throws SQLException;
	public ResponseEntity<String> deleteCompany(int id);

	public List<Company> getCompanyListSector(String sectorName)throws Exception;
	
	public List<String> getPattern(String pattern)throws Exception;

	public Optional<Company> getCompanyById(int id);
	
}
