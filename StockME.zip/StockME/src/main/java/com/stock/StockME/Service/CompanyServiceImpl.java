package com.stock.StockME.Service;


import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.stock.StockME.Dao.CompanyDao;
import com.stock.StockME.Dao.SectorDao;
import com.stock.StockME.Model.Company;
import com.stock.StockME.Model.Sector;


@Service
public class CompanyServiceImpl implements CompanyService {
	@Autowired
	private CompanyDao companyDao;
	@Autowired
	private SectorDao sectorDao;
	@Override
	public Company insertCompany(Company company) throws SQLException {
		// TODO Auto-generated method stub
		Company comp = companyDao.save(company);

		return comp;
	}

	@Override
	public ResponseEntity<String> updateCompany(Company company) {
		// TODO Auto-generated method stub

		Optional<Company> companyData = companyDao.findById(company.getId());

		if (companyData.isPresent()) {

			Company _company = companyData.get();
			_company.setCompanyName(company.getCompanyName());
			_company.setCeo(company.getCeo());
			_company.setBriefWriteUp(company.getBriefWriteUp());
			_company.setStockPriceId(company.getStockPriceId());
			companyDao.save(_company);
			return new ResponseEntity<>("Company Updated", HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	public List<Company> getCompanyList() throws SQLException {
	
		return companyDao.findAll();
	}
	
	@Override
	public ResponseEntity<String> deleteCompany(int id) {
		// TODO Auto-generated method stub
		companyDao.deleteById(id);
		return new ResponseEntity<>("Company has been Deleted", HttpStatus.OK);
	}



	@Override
	public List<Company> getCompanyListSector(String sectorName) throws Exception {
		
		Sector sector=sectorDao.findByName(sectorName);
		return companyDao.findBySectorId(sector.getId());
	}
	
	public Optional<Company> getCompanyById(int id) {
		return companyDao.findById(id);
	}



	@Override
	public List<String> getPattern(String pattern) throws Exception {
	
		return companyDao.getPattern(pattern);
	}

}
