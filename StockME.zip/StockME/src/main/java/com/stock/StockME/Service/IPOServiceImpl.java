package com.stock.StockME.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.StockME.Dao.IPOPlanedDao;
import com.stock.StockME.Model.IPOPlaned;


@Service
public class IPOServiceImpl implements IPOservice {
	@Autowired
	IPOPlanedDao ipoPlanedDao;
	public IPOPlaned getIPOBycompanyName(String companyName) {
		
		return ipoPlanedDao.findByCompanyName(companyName);
	}
	public void insertIPO(IPOPlaned ipoPlaned) throws Exception {
		ipoPlanedDao.save(ipoPlaned);
		
	}

}
