package com.stock.StockME.Service;

import com.stock.StockME.Model.IPOPlaned;

public interface IPOservice {
	public IPOPlaned getIPOBycompanyName(String companyName);
	public void insertIPO(IPOPlaned ipoPlaned)throws Exception;
	
}
