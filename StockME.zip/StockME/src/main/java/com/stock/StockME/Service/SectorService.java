package com.stock.StockME.Service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.stock.StockME.Model.Sector;
import com.stock.StockME.Model.StockPrice;



public interface SectorService {
	public Sector insert (Sector sector)throws ClassNotFoundException, SQLException;
	public List<Sector> getAllSector()throws ClassNotFoundException, SQLException;

	public List<StockPrice> getSectorPrice(String Sector,Date from,Date to)throws ClassNotFoundException, SQLException;
	public ResponseEntity<String> deleteSector(int id);
	public ResponseEntity<String> updateSector(Sector sector);
}
