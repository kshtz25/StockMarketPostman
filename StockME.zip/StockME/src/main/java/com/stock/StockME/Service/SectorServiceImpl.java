package com.stock.StockME.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.stock.StockME.Dao.*;
import com.stock.StockME.Model.Company;
import com.stock.StockME.Model.Sector;
import com.stock.StockME.Model.StockPrice;
@Service
public class SectorServiceImpl implements SectorService {
	@Autowired
	private SectorDao sectorDao;
	@Autowired
	private CompanyDao companyDao;
	@Autowired
	StockPriceDao stockPriceDao;
	public Sector insert(Sector sector) throws ClassNotFoundException, SQLException {
		return sectorDao.save(sector) ;
	}

	public List<Sector> getAllSector() throws ClassNotFoundException, SQLException {
		return sectorDao.findAll();
	}
	@Override
	public ResponseEntity<String> updateSector(Sector sector) {
		// TODO Auto-generated method stub
		Optional<Sector> sectorData = sectorDao.findById(sector.getId());
		if (sectorData.isPresent()) {

			Sector _sector = sectorData.get();
			_sector.setName(sector.getName());
			_sector.setBrief(sector.getBrief());
			sectorDao.save(_sector);
			return new ResponseEntity<>("sector Updated succesfully", HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	
	public List<StockPrice> getSectorPrice(String SectorName,Date from,Date to) throws ClassNotFoundException, SQLException {
		Sector sector=sectorDao.findByName(SectorName);
		
		List<Company> companyList=companyDao.findBySectorId(sector.getId());
		System.out.println(from);
		List<StockPrice> stockPriceList =new ArrayList<>();
		for(Company company:companyList)
		{
			
		List<StockPrice> companyStock=stockPriceDao.getStockPrice(company.getId(), from, to);
			stockPriceList.addAll(companyStock);
		}
		return stockPriceList;
	}
	@Override
	public ResponseEntity<String> deleteSector(int id) {
		// TODO Auto-generated method stub
		sectorDao.deleteById(id);
		return new ResponseEntity<>("Sector has been Deleted", HttpStatus.OK);
	}

	

}
