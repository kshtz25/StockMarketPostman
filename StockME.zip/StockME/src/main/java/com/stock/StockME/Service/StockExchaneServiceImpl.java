package com.stock.StockME.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.StockME.Dao.StockExchangeDao;
import com.stock.StockME.Model.StockExchange;


@Service
public class StockExchaneServiceImpl implements StockExchangeService {
	@Autowired
	StockExchangeDao  stockExchangeDao;
	@Override
	public List<StockExchange> getStockList() {
				return stockExchangeDao.findAll();
	}

}
