package com.stock.StockME.Service;

import java.util.List;

import com.stock.StockME.Model.StockExchange;



public interface StockExchangeService {
public List<StockExchange> getStockList();
}
