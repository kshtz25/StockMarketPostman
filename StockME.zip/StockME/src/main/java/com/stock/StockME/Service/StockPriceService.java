package com.stock.StockME.Service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.stock.StockME.Model.StockPrice;



public interface StockPriceService {
	public List<StockPrice> getStockPriceByCompany(String companyName)throws Exception;
	public StockPrice insertStockPrice(StockPrice stockPrice) throws SQLException;
	public ResponseEntity<String> updateStockPrice(StockPrice stockPrice);
	public List<StockPrice> getStockPriceList() throws SQLException;
	public ResponseEntity<String> deleteStockPrice(int id);
	
}
