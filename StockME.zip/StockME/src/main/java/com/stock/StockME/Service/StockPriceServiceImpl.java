package com.stock.StockME.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.stock.StockME.Dao.CompanyDao;
import com.stock.StockME.Dao.StockPriceDao;
import com.stock.StockME.Model.Company;
import com.stock.StockME.Model.StockPrice;


@Service
public class StockPriceServiceImpl implements StockPriceService{
	@Autowired
	StockPriceDao stockPriceDao;
	@Autowired
	CompanyDao companyDao;
	
	@Override
	public StockPrice insertStockPrice(StockPrice stockPrice) throws SQLException {
		// TODO Auto-generated method stub
		return stockPriceDao.save(stockPrice);
	}
	
	public List<StockPrice> getStockPriceByCompany(String companyName) throws Exception {
		Company company=companyDao.findByCompanyName(companyName);
		return stockPriceDao.findByCompanyCode(company.getId());
	}
	@Override
	public ResponseEntity<String> updateStockPrice(StockPrice stockPrice) {
		// TODO Auto-generated method stub
		Optional<StockPrice> stockPriceData = stockPriceDao.findById(stockPrice.getId());

		if (stockPriceData.isPresent()) {

			StockPrice _stockPrice = stockPriceData.get();
			_stockPrice.setStockExchange(stockPrice.getStockExchange());
			_stockPrice.setCurrentPrice(stockPrice.getCurrentPrice());
			_stockPrice.setDate(stockPrice.getDate());
			return new ResponseEntity<>("Stock Price Updated successfully", HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public List<StockPrice> getStockPriceList() throws SQLException {
		// TODO Auto-generated method stub
		List<StockPrice> stockPrices = new ArrayList<>();
		stockPriceDao.findAll().forEach(stockPrices::add);

		return stockPrices;
	}

	@Override
	public ResponseEntity<String> deleteStockPrice(int id) {
		// TODO Auto-generated method stub
		stockPriceDao.deleteById(id);
		return new ResponseEntity<>("Stock Price has been Deleted",HttpStatus.OK);
	}
	

}
