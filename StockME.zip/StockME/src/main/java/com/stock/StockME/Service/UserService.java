package com.stock.StockME.Service;

import java.util.List;
import java.util.Optional;

import com.stock.StockME.Model.User;



public interface UserService {
	 public User registerUser(User user) throws Exception;
	 public User updateUser(User user)throws Exception;
	 public List<User> getUserList();
	Optional<User> getUserById(int userId);
}
