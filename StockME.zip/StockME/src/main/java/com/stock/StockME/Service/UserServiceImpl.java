package com.stock.StockME.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.StockME.Dao.UserDao;
import com.stock.StockME.Model.User;


@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;

	public User registerUser(User user) throws Exception {
		
		return userDao.save(user);

	}

	
	public User updateUser(User user) throws Exception {
		return userDao.save(user);
	
	}


	@Override
	public List<User> getUserList() {
		// TODO Auto-generated method stub
		return userDao.findAll();
	}
	
	public Optional<User> getUserById(int userId) {
		return (Optional<User>) userDao.findById(userId);
	}

	

}
